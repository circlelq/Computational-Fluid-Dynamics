global gamma
global dx
global N
global F
global W
global U2
global U21
global CFL
