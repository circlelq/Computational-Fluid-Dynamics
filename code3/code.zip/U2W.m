function [ rho ] = U2rho( U )
% transform U to W
%   U: [rho rho*u rho*E]
%   W: [rho u v p]

global gamma;

rho = U(:, :, 1);
t1  = U(:, :, 2);
t2  = U(:, :, 3);
m   = U(:, :, 4);


u   = t1./rho;
v   = t2./rho;
p   = (gamma-1)*(m-0.5.*rho.*u.^2-0.5.*rho.*v.^2);

% rho = 0.5*(abs(rho)+rho);
% p  = 0.5*(abs(p)+p);

rho(:, :, 1)   = rho;
rho(:, :, 2)   = u;
rho(:, :, 3)   = v;
rho(:, :, 4)   = p;

end
